﻿using Boutique.DAL;
using Boutique.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boutique.BUS
{
    class ChiTietDonThueBUS
    {
        private ChiTietDonThue chiTienDonThue = new ChiTietDonThue();

        public bool InsertChiTietDonThue(ChiTietDonThueDTO chiTietDth)
        {
            return chiTienDonThue.InsertChiTietDonThue(chiTietDth);
        }

        public string GenerateNewChiTietDonThueID(string prefix)
        {
            return chiTienDonThue.GenerateNewChiTietDonThueID(prefix);
        }
    }
}
