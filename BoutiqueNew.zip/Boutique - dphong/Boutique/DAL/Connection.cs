﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Boutique.BUS;
//using Microsoft.Data.SqlClient;


//namespace Boutique.DAL
//{
//    class Connection
//    {
//        //private static SqlConnection connection;
//        private NhanVienBUS nhanVienBUS = new NhanVienBUS();
//        public static SqlConnection connect()
//        {
//            String sql = "";
//            if (Program.authen == "windows")
//            {
//                sql = "Data Source=" + Program.server + ";Initial Catalog=" + Program.database + ";Integrated Security=True;TrustServerCertificate=True;";
//            }
//            else
//            {
//                sql = "server = " + Program.server + "; database = " + Program.database + "; uid = " + Program.uid + "; pwd = " + Program.password;
//            }

//            try
//            {
//                //    connection = new SqlConnection(sql);
//                //    connection.Open();
//                //    //MessageBox.Show("Connect database successfully");
//                //    return connection;

//                SqlConnection connection = new SqlConnection(sql);
//                return connection;
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error: " + ex.Message);
//                return null;
//            }
//        }

//        //public static void actionQuery(string query)
//        //{
//        //    using (SqlConnection connection = connect())
//        //    {
//        //        if (connection != null)
//        //        {
//        //            using (SqlCommand cmd = new SqlCommand(query, connection))
//        //            {
//        //                cmd.ExecuteNonQuery();
//        //            }
//        //        }
//        //    }
//        //}


//        public static void ActionQuery(string query, params SqlParameter[] para)
//        {
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    using (SqlCommand cmd = new SqlCommand(query, connection))
//                    {
//                        if (para != null && para.Length > 0)
//                        {
//                            cmd.Parameters.AddRange(para);
//                        }
//                        cmd.ExecuteNonQuery();
//                    }
//                }
//                else
//                {
//                    throw new Exception("Can not connect to server!");
//                }
//            }
//        }

//        public static int ActionQueryWithReturn(string query, params SqlParameter[] para)
//        {
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    connection.Open();
//                    using (SqlCommand cmd = new SqlCommand(query, connection))
//                    {
//                        if (para != null && para.Length > 0)
//                        {
//                            cmd.Parameters.AddRange(para);
//                        }
//                        return cmd.ExecuteNonQuery();
//                    }
//                }
//                else
//                {
//                    throw new Exception("Can not connect to server!");
//                }
//            }
//        }

//        //phương thức ExecuteScalar để lấy giá trị SUM
//        public object ExecuteScalar(string query, SqlParameter[] parameters)
//        {
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    using (SqlCommand cmd = new SqlCommand(query, connection))
//                    {
//                        if (parameters != null && parameters.Length > 0)
//                        {
//                            cmd.Parameters.AddRange(parameters);
//                        }
//                        return cmd.ExecuteScalar(); // Trả về kết quả SUM
//                    }
//                }
//                throw new Exception("Không thể kết nối CSDL!");
//            }
//        }

//        public string checkLogin(string username, string password)
//        {
//            string role = null; // Lưu loại tài khoản ("admin" hoặc "staff")
//            connect();

//            string queryAdmin = "SELECT COUNT(*) FROM admin WHERE adminName = @username AND adminPassword = @password";
//            string queryStaff = "SELECT COUNT(*) FROM staff WHERE staffName = @username AND staffPassword = @password";
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
//                    {
//                        cmd.Parameters.AddWithValue("@username", username);
//                        cmd.Parameters.AddWithValue("@password", password);
//                        int count = (int)cmd.ExecuteScalar();
//                        if (count > 0)
//                        {
//                            role = "admin"; // Tìm thấy trong bảng admin
//                        }
//                    }

//                    if (role == null) // Nếu chưa tìm thấy trong admin thì tìm tiếp trong staff
//                    {
//                        using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
//                        {
//                            cmd.Parameters.AddWithValue("@username", username);
//                            cmd.Parameters.AddWithValue("@password", password);
//                            int count = (int)cmd.ExecuteScalar();
//                            if (count > 0)
//                            {
//                                role = "staff"; // Tìm thấy trong bảng staff
//                            }
//                        }
//                    }
//                }
//                connection.Close();
//            }

//            return role; // Trả về "admin", "staff" hoặc null nếu không tìm thấy

//        }

//        //tạo id tự động cho admin
//        private string GenerateNewAdminID()
//        {
//            //code here
//            string newID = "AD001";
//            string query = "SELECT MAX(adminID) FROM admin";

//            connect();
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    using (SqlCommand cmd = new SqlCommand(query, connection))
//                    {
//                        object result = cmd.ExecuteScalar();
//                        if (result != DBNull.Value && result != null)
//                        {
//                            string lastID = result.ToString(); // VD: "US009"
//                            int number = int.Parse(lastID.Substring(2)); // Lấy số "009"
//                            newID = "AD" + (number + 1).ToString("D3"); // Tăng 1 -> "US010"
//                        }
//                    }
//                }
//            }

//            return newID;
//        }

//        //tạo id tự động cho staff
//        private string GenerateNewStaffID()
//        {
//            string newID = "ST001";
//            string query = "SELECT MAX(staffID) FROM staff";
//            connect();
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    using (SqlCommand cmd = new SqlCommand(query, connection))
//                    {
//                        object result = cmd.ExecuteScalar();
//                        if (result != DBNull.Value && result != null)
//                        {
//                            string lastID = result.ToString(); // VD: "US009"
//                            int number = int.Parse(lastID.Substring(2)); // Lấy số "009"
//                            newID = "ST" + (number + 1).ToString("D3"); // Tăng 1 -> "US010"
//                        }
//                    }
//                }
//            }

//            return newID;
//        }
//        public bool insertUser(string username, string password, string role, string email)
//        {
//            //code here
//            string newAdminID = GenerateNewAdminID();
//            string newStaffID = GenerateNewStaffID();
//            //connect();
//            using (SqlConnection connection = connect())
//            {
//                if (connection != null)
//                {
//                    if (role == "admin")
//                    {
//                        string queryAdmin = "INSERT INTO admin (adminID, adminName, adminPassword, adminEmail) VALUES (@adminID, @adminName, @adminPassword, @adminEmail)";
//                        using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
//                        {
//                            cmd.Parameters.AddWithValue("@adminID", newAdminID);
//                            cmd.Parameters.AddWithValue("@adminName", username);
//                            cmd.Parameters.AddWithValue("@adminPassword", password);
//                            cmd.Parameters.AddWithValue("@adminEmail", email);

//                            int rows = cmd.ExecuteNonQuery();
//                            return rows > 0;
//                        }
//                    }
//                    else
//                    {
//                        //string newStaffID = GenerateNewAdminID("ST");
//                        string queryStaff = "INSERT INTO staff (staffID, staffName, staffPassword, staffEmail) VALUES (@staffID, @staffName, @staffPassword, @staffEmail)";

//                        using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
//                        {
//                            cmd.Parameters.AddWithValue("@staffID", newStaffID);
//                            cmd.Parameters.AddWithValue("@staffName", username);
//                            cmd.Parameters.AddWithValue("@staffPassword", password);
//                            cmd.Parameters.AddWithValue("@staffEmail", email);

//                            int rows = cmd.ExecuteNonQuery();
//                            //return rows > 0;
//                            if (rows > 0)
//                            {
//                                string maStaffChiTiet = nhanVienBUS.GenerateNewID("Staff");
//                                string queryInsert = "INSERT INTO staffChiTiet(maStaffChiTiet, staffID, email) VALUES (@maStaffChiTiet, @staffID, @email)";
//                                using (SqlCommand cmdNew = new SqlCommand(queryInsert, connection))
//                                {
//                                    cmdNew.Parameters.AddWithValue("@maStaffChiTiet", maStaffChiTiet);
//                                    cmdNew.Parameters.AddWithValue("@staffID", newStaffID);
//                                    cmdNew.Parameters.AddWithValue("@email", email);
//                                    int rowsEffected = cmdNew.ExecuteNonQuery();
//                                    return rowsEffected > 0;
//                                }
//                                //return true;
//                            }

//                        }
//                    }
//                }
//                return false;
//            }


//        }
//    }
//}

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Boutique.DAL
{
    class Connection
    {
        public static SqlConnection connect()
        {
            string sql;
            if (Program.authen == "windows")
            {
                sql = $"Data Source={Program.server};Initial Catalog={Program.database};Integrated Security=True;TrustServerCertificate=True;";
            }
            else
            {
                sql = $"Server={Program.server};Database={Program.database};Uid={Program.uid};Pwd={Program.password};TrustServerCertificate=True;";
            }

            return new SqlConnection(sql);
        }

        public static void ActionQuery(string query, params SqlParameter[] para)
        {
            using (SqlConnection connection = connect())
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    if (para != null && para.Length > 0)
                    {
                        cmd.Parameters.AddRange(para);
                    }
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static int ActionQueryWithReturn(string query, params SqlParameter[] para)
        {
            using (SqlConnection connection = connect())
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    if (para != null && para.Length > 0)
                    {
                        cmd.Parameters.AddRange(para);
                    }
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static object ExecuteScalar(string query, SqlParameter[] parameters)
        {
            using (SqlConnection connection = connect())
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    if (parameters != null && parameters.Length > 0)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    return cmd.ExecuteScalar();
                }
            }
        }

        //public static string checkLogin(string username, string password)
        //{
        //    string role = null;

        //    using (SqlConnection connection = connect())
        //    {
        //        connection.Open();

        //        string queryAdmin = "SELECT COUNT(*) FROM admin WHERE adminName = @username AND adminPassword = @password";
        //        using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
        //        {
        //            cmd.Parameters.AddWithValue("@username", username);
        //            cmd.Parameters.AddWithValue("@password", password);
        //            int count = (int)cmd.ExecuteScalar();
        //            if (count > 0)
        //            {
        //                return "admin";
        //            }
        //        }

        //        string queryStaff = "SELECT COUNT(*) FROM staff WHERE staffName = @username AND staffPassword = @password";
        //        using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
        //        {
        //            cmd.Parameters.AddWithValue("@username", username);
        //            cmd.Parameters.AddWithValue("@password", password);
        //            int count = (int)cmd.ExecuteScalar();
        //            if (count > 0)
        //            {
        //                return "staff";
        //            }
        //        }
        //    }

        //    return role;
        //}

        //public string checkLogin(string username, string password)
        //{
        //    string role = null; // Lưu loại tài khoản ("admin" hoặc "staff")

        //    try
        //    {
        //        string queryAdmin = "SELECT COUNT(*) FROM admin WHERE adminName = @username AND adminPassword = @password";
        //        string queryStaff = "SELECT COUNT(*) FROM staff WHERE staffName = @username AND staffPassword = @password";

        //        using (SqlConnection connection = connect())
        //        {
        //            if (connection != null)
        //            {
        //                using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
        //                {
        //                    cmd.Parameters.AddWithValue("@username", username);
        //                    cmd.Parameters.AddWithValue("@password", password);
        //                    int count = (int)cmd.ExecuteScalar();
        //                    if (count > 0)
        //                    {
        //                        role = "admin"; // Tìm thấy trong bảng admin
        //                    }
        //                }

        //                if (role == null) // Nếu chưa tìm thấy trong admin thì tìm tiếp trong staff
        //                {
        //                    using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
        //                    {
        //                        cmd.Parameters.AddWithValue("@username", username);
        //                        cmd.Parameters.AddWithValue("@password", password);
        //                        int count = (int)cmd.ExecuteScalar();
        //                        if (count > 0)
        //                        {
        //                            role = "staff"; // Tìm thấy trong bảng staff
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error during login: " + ex.Message);
        //    }

        //    return role; // Trả về "admin", "staff" hoặc null nếu không tìm thấy
        //}

        //public string checkLogin(string username, string password)
        //{
        //    string role = null; // Lưu loại tài khoản ("admin" hoặc "staff")

        //    SqlConnection connection = null;

        //    try
        //    {
        //        // Kết nối tới CSDL
        //        connection = connect();

        //        if (connection != null)
        //        {
        //            string queryAdmin = "SELECT COUNT(*) FROM admin WHERE adminName = @username AND adminPassword = @password";
        //            string queryStaff = "SELECT COUNT(*) FROM staff WHERE staffName = @username AND staffPassword = @password";

        //            // Kiểm tra trong bảng admin
        //            using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
        //            {
        //                cmd.Parameters.AddWithValue("@username", username);
        //                cmd.Parameters.AddWithValue("@password", password);
        //                int count = (int)cmd.ExecuteScalar();
        //                if (count > 0)
        //                {
        //                    role = "admin"; // Tìm thấy trong bảng admin
        //                }
        //            }

        //            // Kiểm tra trong bảng staff nếu không tìm thấy trong admin
        //            if (role == null)
        //            {
        //                using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
        //                {
        //                    cmd.Parameters.AddWithValue("@username", username);
        //                    cmd.Parameters.AddWithValue("@password", password);
        //                    int count = (int)cmd.ExecuteScalar();
        //                    if (count > 0)
        //                    {
        //                        role = "staff"; // Tìm thấy trong bảng staff
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error during login: " + ex.Message);
        //    }
        //    finally
        //    {
        //        // Đảm bảo kết nối luôn được đóng trong khối finally
        //        if (connection != null && connection.State != ConnectionState.Closed)
        //        {
        //            connection.Close();
        //        }
        //    }

        //    return role; // Trả về "admin", "staff" hoặc null nếu không tìm thấy
        //}

        public string checkLogin(string username, string password)
        {
            string role = null; // Lưu loại tài khoản ("admin" hoặc "staff")

            try
            {
                // Kết nối tới CSDL
                using (SqlConnection connection = connect())
                {
                    connection.Open();

                    string queryAdmin = "SELECT COUNT(*) FROM admin WHERE adminName = @username AND adminPassword = @password";
                    string queryStaff = "SELECT COUNT(*) FROM staff WHERE staffName = @username AND staffPassword = @password";

                    // Kiểm tra trong bảng admin
                    using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        int count = (int)cmd.ExecuteScalar();
                        if (count > 0)
                        {
                            role = "admin"; // Tìm thấy trong bảng admin
                        }
                    }

                    // Kiểm tra trong bảng staff nếu không tìm thấy trong admin
                    if (role == null)
                    {
                        using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
                        {
                            cmd.Parameters.AddWithValue("@username", username);
                            cmd.Parameters.AddWithValue("@password", password);
                            int count = (int)cmd.ExecuteScalar();
                            if (count > 0)
                            {
                                role = "staff"; // Tìm thấy trong bảng staff
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during login: " + ex.Message);
            }

            return role; // Trả về "admin", "staff" hoặc null nếu không tìm thấy
        }



        private static string GenerateNewAdminID()
        {
            string newID = "AD001";
            string query = "SELECT MAX(adminID) FROM admin";

            using (SqlConnection connection = connect())
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        string lastID = result.ToString();
                        int number = int.Parse(lastID.Substring(2));
                        newID = "AD" + (number + 1).ToString("D3");
                    }
                }
            }

            return newID;
        }

        private static string GenerateNewStaffID()
        {
            string newID = "ST001";
            string query = "SELECT MAX(staffID) FROM staff";

            using (SqlConnection connection = connect())
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        string lastID = result.ToString();
                        int number = int.Parse(lastID.Substring(2));
                        newID = "ST" + (number + 1).ToString("D3");
                    }
                }
            }

            return newID;
        }

        public static bool insertUser(string username, string password, string role, string email)
        {
            string newAdminID = GenerateNewAdminID();
            string newStaffID = GenerateNewStaffID();

            using (SqlConnection connection = connect())
            {
                connection.Open();

                if (role == "admin")
                {
                    string queryAdmin = "INSERT INTO admin (adminID, adminName, adminPassword, adminEmail) VALUES (@adminID, @adminName, @adminPassword, @adminEmail)";
                    using (SqlCommand cmd = new SqlCommand(queryAdmin, connection))
                    {
                        cmd.Parameters.AddWithValue("@adminID", newAdminID);
                        cmd.Parameters.AddWithValue("@adminName", username);
                        cmd.Parameters.AddWithValue("@adminPassword", password);
                        cmd.Parameters.AddWithValue("@adminEmail", email);

                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
                else
                {
                    string queryStaff = "INSERT INTO staff (staffID, staffName, staffPassword, staffEmail) VALUES (@staffID, @staffName, @staffPassword, @staffEmail)";
                    using (SqlCommand cmd = new SqlCommand(queryStaff, connection))
                    {
                        cmd.Parameters.AddWithValue("@staffID", newStaffID);
                        cmd.Parameters.AddWithValue("@staffName", username);
                        cmd.Parameters.AddWithValue("@staffPassword", password);
                        cmd.Parameters.AddWithValue("@staffEmail", email);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            // Thêm dòng staffChiTiet
                            string maStaffChiTiet = newStaffID.Replace("ST", "CT"); // ví dụ đơn giản tạo mã chi tiết
                            string queryInsert = "INSERT INTO staffChiTiet(maStaffChiTiet, staffID, email) VALUES (@maStaffChiTiet, @staffID, @email)";
                            using (SqlCommand cmdDetail = new SqlCommand(queryInsert, connection))
                            {
                                cmdDetail.Parameters.AddWithValue("@maStaffChiTiet", maStaffChiTiet);
                                cmdDetail.Parameters.AddWithValue("@staffID", newStaffID);
                                cmdDetail.Parameters.AddWithValue("@email", email);
                                return cmdDetail.ExecuteNonQuery() > 0;
                            }
                        }
                    }
                }
            }

            return false;
        }
    }
}
