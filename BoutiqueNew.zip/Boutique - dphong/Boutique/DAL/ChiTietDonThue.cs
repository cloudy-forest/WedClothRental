﻿using Boutique.DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boutique.DAL
{
    class ChiTietDonThue
    {
        public bool InsertChiTietDonThue(ChiTietDonThueDTO chiTietDonThue)
        {
            string queryInsert = "INSERT INTO chiTietDonThue (maChiTietDonThue, maDonThue, maSanPham, soLuong, giaThue, soNgayThue, ghiChu) " +
                "VALUES (@maChiTietDonThue, @maDonThue, @maSanPham, @soLuong, @giaThue, @soNgayThue, @ghiChu)";

            SqlParameter[] paraInsert = new SqlParameter[]
            {
                new SqlParameter("@maChiTietDonThue", chiTietDonThue.GetMaChiTietDonThue()),
                new SqlParameter("@maDonThue", chiTietDonThue.GetMaDonThue()),
                new SqlParameter("@maSanPham", chiTietDonThue.GetMaSanPham()),
                new SqlParameter("@soLuong", chiTietDonThue.GetSoLuong()),
                new SqlParameter("@giaThue", chiTietDonThue.GetGiaThue()),
                new SqlParameter("@soNgayThue", chiTietDonThue.GetSoNgayThue()),
                new SqlParameter("@ghiChu", chiTietDonThue.GetGhiChu())
            };

            int rowAffected = Connection.ActionQueryWithReturn(queryInsert, paraInsert);
            return rowAffected > 0;
        }

        public string GenerateNewChiTietDonThueID(string prefix)
        {
            string newID = prefix + "001";
            string query = "SELECT MAX(maChiTietDonThue) FROM chiTietDonThue";
            using (SqlConnection connection = Connection.connect())
            {
                if (connection != null)
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value && result != null)
                        {
                            string lastID = result.ToString(); // VD: "US009"
                            int number = int.Parse(lastID.Substring(4)); // Lấy số "009"
                            newID = prefix + (number + 1).ToString("D3"); // Tăng 1 -> "US010"
                        }
                    }
                }
            }
            return newID;
        }
    }
}
