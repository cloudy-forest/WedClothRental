﻿namespace Boutique.GUI
{
    partial class ForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            forgot = new Label();
            label1 = new Label();
            emailReserPw_txt = new TextBox();
            verifyEmail_btn = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.GradientInactiveCaption;
            panel1.Controls.Add(verifyEmail_btn);
            panel1.Controls.Add(emailReserPw_txt);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(forgot);
            panel1.Location = new Point(122, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(331, 169);
            panel1.TabIndex = 0;
            // 
            // forgot
            // 
            forgot.AutoSize = true;
            forgot.Font = new Font("Arial Black", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            forgot.Location = new Point(25, 9);
            forgot.Name = "forgot";
            forgot.Size = new Size(284, 33);
            forgot.TabIndex = 0;
            forgot.Text = "FORGOT PASSWORD";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(25, 57);
            label1.Name = "label1";
            label1.Size = new Size(114, 17);
            label1.TabIndex = 1;
            label1.Text = "Enter your email";
            // 
            // emailReserPw_txt
            // 
            emailReserPw_txt.BackColor = SystemColors.GradientInactiveCaption;
            emailReserPw_txt.BorderStyle = BorderStyle.FixedSingle;
            emailReserPw_txt.Location = new Point(25, 86);
            emailReserPw_txt.Name = "emailReserPw_txt";
            emailReserPw_txt.Size = new Size(284, 23);
            emailReserPw_txt.TabIndex = 2;
            // 
            // verifyEmail_btn
            // 
            verifyEmail_btn.BackColor = SystemColors.GradientInactiveCaption;
            verifyEmail_btn.FlatAppearance.BorderColor = SystemColors.GradientInactiveCaption;
            verifyEmail_btn.FlatAppearance.BorderSize = 0;
            verifyEmail_btn.FlatAppearance.MouseDownBackColor = Color.White;
            verifyEmail_btn.FlatAppearance.MouseOverBackColor = Color.White;
            verifyEmail_btn.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            verifyEmail_btn.Location = new Point(205, 127);
            verifyEmail_btn.Name = "verifyEmail_btn";
            verifyEmail_btn.Size = new Size(104, 28);
            verifyEmail_btn.TabIndex = 3;
            verifyEmail_btn.Text = "Verify email";
            verifyEmail_btn.UseVisualStyleBackColor = false;
            // 
            // ForgotPassword
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(562, 324);
            Controls.Add(panel1);
            Name = "ForgotPassword";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Forgot Password";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox emailReserPw_txt;
        private Label label1;
        private Label forgot;
        private Button verifyEmail_btn;
    }
}