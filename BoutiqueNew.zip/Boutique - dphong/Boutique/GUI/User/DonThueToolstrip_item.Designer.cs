﻿namespace Boutique.GUI.User
{
    partial class DonThueToolstrip_item
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            panel1 = new Panel();
            insertDonThue_btn = new Button();
            insertSanPham_btn = new Button();
            giaThue_txt = new TextBox();
            label10 = new Label();
            soNgayThue_txt = new TextBox();
            label9 = new Label();
            soLuong_txt = new TextBox();
            label8 = new Label();
            maSanPham_txt = new TextBox();
            label3 = new Label();
            chiTietDonThue_btn = new Button();
            deleteDonThue_btn = new Button();
            label7 = new Label();
            ghiChu_txt = new RichTextBox();
            traDuKien_date = new DateTimePicker();
            label6 = new Label();
            tienCoc_txt = new TextBox();
            label5 = new Label();
            nhanHang_date = new DateTimePicker();
            label4 = new Label();
            maKhachHang_txt = new TextBox();
            label2 = new Label();
            maDonThue_txt = new TextBox();
            label1 = new Label();
            donThueList_panel = new Panel();
            donThueList = new DataGridView();
            panel1.SuspendLayout();
            donThueList_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)donThueList).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(insertDonThue_btn);
            panel1.Controls.Add(insertSanPham_btn);
            panel1.Controls.Add(giaThue_txt);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(soNgayThue_txt);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(soLuong_txt);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(maSanPham_txt);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(chiTietDonThue_btn);
            panel1.Controls.Add(deleteDonThue_btn);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(ghiChu_txt);
            panel1.Controls.Add(traDuKien_date);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(tienCoc_txt);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(nhanHang_date);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(maKhachHang_txt);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(maDonThue_txt);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1158, 242);
            panel1.TabIndex = 0;
            // 
            // insertDonThue_btn
            // 
            insertDonThue_btn.BackColor = Color.PowderBlue;
            insertDonThue_btn.FlatAppearance.BorderSize = 0;
            insertDonThue_btn.FlatStyle = FlatStyle.Flat;
            insertDonThue_btn.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            insertDonThue_btn.Location = new Point(467, 195);
            insertDonThue_btn.Name = "insertDonThue_btn";
            insertDonThue_btn.Size = new Size(89, 27);
            insertDonThue_btn.TabIndex = 13;
            insertDonThue_btn.Text = "Thêm đơn";
            insertDonThue_btn.UseVisualStyleBackColor = false;
            insertDonThue_btn.Click += insertDonThue_btn_Click;
            // 
            // insertSanPham_btn
            // 
            insertSanPham_btn.BackColor = Color.PowderBlue;
            insertSanPham_btn.FlatAppearance.BorderSize = 0;
            insertSanPham_btn.FlatStyle = FlatStyle.Flat;
            insertSanPham_btn.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            insertSanPham_btn.Location = new Point(977, 195);
            insertSanPham_btn.Name = "insertSanPham_btn";
            insertSanPham_btn.Size = new Size(136, 27);
            insertSanPham_btn.TabIndex = 24;
            insertSanPham_btn.Text = "Thêm sản phẩm";
            insertSanPham_btn.UseVisualStyleBackColor = false;
            insertSanPham_btn.Click += insertSanPham_btn_Click;
            // 
            // giaThue_txt
            // 
            giaThue_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            giaThue_txt.Location = new Point(601, 109);
            giaThue_txt.Name = "giaThue_txt";
            giaThue_txt.Size = new Size(200, 26);
            giaThue_txt.TabIndex = 23;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(451, 109);
            label10.Name = "label10";
            label10.Size = new Size(80, 22);
            label10.TabIndex = 22;
            label10.Text = "Giá thuê";
            // 
            // soNgayThue_txt
            // 
            soNgayThue_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            soNgayThue_txt.Location = new Point(959, 19);
            soNgayThue_txt.Name = "soNgayThue_txt";
            soNgayThue_txt.Size = new Size(173, 26);
            soNgayThue_txt.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(833, 19);
            label9.Name = "label9";
            label9.Size = new Size(120, 22);
            label9.TabIndex = 20;
            label9.Text = "Số ngày thuê";
            // 
            // soLuong_txt
            // 
            soLuong_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            soLuong_txt.Location = new Point(601, 147);
            soLuong_txt.Name = "soLuong_txt";
            soLuong_txt.Size = new Size(200, 26);
            soLuong_txt.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(451, 151);
            label8.Name = "label8";
            label8.Size = new Size(89, 22);
            label8.TabIndex = 18;
            label8.Text = "Số lượng";
            // 
            // maSanPham_txt
            // 
            maSanPham_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            maSanPham_txt.Location = new Point(261, 109);
            maSanPham_txt.Name = "maSanPham_txt";
            maSanPham_txt.Size = new Size(144, 26);
            maSanPham_txt.TabIndex = 17;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(115, 155);
            label3.Name = "label3";
            label3.Size = new Size(82, 22);
            label3.TabIndex = 16;
            label3.Text = "Tiền cọc";
            // 
            // chiTietDonThue_btn
            // 
            chiTietDonThue_btn.BackColor = Color.PowderBlue;
            chiTietDonThue_btn.FlatAppearance.BorderSize = 0;
            chiTietDonThue_btn.FlatStyle = FlatStyle.Flat;
            chiTietDonThue_btn.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chiTietDonThue_btn.Location = new Point(726, 195);
            chiTietDonThue_btn.Name = "chiTietDonThue_btn";
            chiTietDonThue_btn.Size = new Size(75, 27);
            chiTietDonThue_btn.TabIndex = 15;
            chiTietDonThue_btn.Text = "Chi tiết";
            chiTietDonThue_btn.UseVisualStyleBackColor = false;
            chiTietDonThue_btn.Click += chiTietDonThue_btn_Click;
            // 
            // deleteDonThue_btn
            // 
            deleteDonThue_btn.BackColor = Color.PowderBlue;
            deleteDonThue_btn.FlatAppearance.BorderSize = 0;
            deleteDonThue_btn.FlatStyle = FlatStyle.Flat;
            deleteDonThue_btn.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deleteDonThue_btn.Location = new Point(601, 195);
            deleteDonThue_btn.Name = "deleteDonThue_btn";
            deleteDonThue_btn.Size = new Size(87, 27);
            deleteDonThue_btn.TabIndex = 14;
            deleteDonThue_btn.Text = "Xóa";
            deleteDonThue_btn.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(833, 113);
            label7.Name = "label7";
            label7.Size = new Size(74, 22);
            label7.TabIndex = 12;
            label7.Text = "Ghi chú";
            // 
            // ghiChu_txt
            // 
            ghiChu_txt.Location = new Point(958, 63);
            ghiChu_txt.Name = "ghiChu_txt";
            ghiChu_txt.Size = new Size(174, 110);
            ghiChu_txt.TabIndex = 1;
            ghiChu_txt.Text = "";
            // 
            // traDuKien_date
            // 
            traDuKien_date.Location = new Point(601, 63);
            traDuKien_date.Name = "traDuKien_date";
            traDuKien_date.Size = new Size(200, 23);
            traDuKien_date.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(451, 60);
            label6.Name = "label6";
            label6.Size = new Size(147, 22);
            label6.TabIndex = 10;
            label6.Text = "Ngày trả dự kiến";
            // 
            // tienCoc_txt
            // 
            tienCoc_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tienCoc_txt.Location = new Point(261, 151);
            tienCoc_txt.Name = "tienCoc_txt";
            tienCoc_txt.Size = new Size(144, 26);
            tienCoc_txt.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(115, 109);
            label5.Name = "label5";
            label5.Size = new Size(122, 22);
            label5.TabIndex = 8;
            label5.Text = "Mã sản phẩm";
            // 
            // nhanHang_date
            // 
            nhanHang_date.Location = new Point(601, 18);
            nhanHang_date.Name = "nhanHang_date";
            nhanHang_date.Size = new Size(200, 23);
            nhanHang_date.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(451, 18);
            label4.Name = "label4";
            label4.Size = new Size(144, 22);
            label4.TabIndex = 6;
            label4.Text = "Ngày nhận hàng";
            // 
            // maKhachHang_txt
            // 
            maKhachHang_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            maKhachHang_txt.Location = new Point(261, 60);
            maKhachHang_txt.Name = "maKhachHang_txt";
            maKhachHang_txt.Size = new Size(144, 26);
            maKhachHang_txt.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(115, 60);
            label2.Name = "label2";
            label2.Size = new Size(135, 22);
            label2.TabIndex = 2;
            label2.Text = "Mã khách hàng";
            // 
            // maDonThue_txt
            // 
            maDonThue_txt.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            maDonThue_txt.Location = new Point(261, 14);
            maDonThue_txt.Name = "maDonThue_txt";
            maDonThue_txt.Size = new Size(144, 26);
            maDonThue_txt.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(115, 14);
            label1.Name = "label1";
            label1.Size = new Size(73, 22);
            label1.TabIndex = 0;
            label1.Text = "Mã đơn";
            // 
            // donThueList_panel
            // 
            donThueList_panel.Controls.Add(donThueList);
            donThueList_panel.Dock = DockStyle.Fill;
            donThueList_panel.Location = new Point(0, 242);
            donThueList_panel.Name = "donThueList_panel";
            donThueList_panel.Size = new Size(1158, 409);
            donThueList_panel.TabIndex = 1;
            // 
            // donThueList
            // 
            donThueList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            donThueList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            donThueList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            donThueList.DefaultCellStyle = dataGridViewCellStyle2;
            donThueList.Dock = DockStyle.Fill;
            donThueList.Location = new Point(0, 0);
            donThueList.Name = "donThueList";
            donThueList.Size = new Size(1158, 409);
            donThueList.TabIndex = 0;
            donThueList.CellClick += donThueList_CellClick;
            // 
            // DonThueToolstrip_item
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(donThueList_panel);
            Controls.Add(panel1);
            Name = "DonThueToolstrip_item";
            Size = new Size(1158, 651);
            Load += DonThueToolstrip_item_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            donThueList_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)donThueList).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox maDonThue_txt;
        private Label label1;
        private Label label2;
        private TextBox maKhachHang_txt;
        private TextBox tienCoc_txt;
        private Label label5;
        private DateTimePicker nhanHang_date;
        private Label label4;
        private DateTimePicker traDuKien_date;
        private Label label6;
        private RichTextBox ghiChu_txt;
        private Label label7;
        private Panel donThueList_panel;
        private DataGridView donThueList;
        private Button chiTietDonThue_btn;
        private Button deleteDonThue_btn;
        private Button insertDonThue_btn;
        private TextBox giaThue_txt;
        private Label label10;
        private TextBox soNgayThue_txt;
        private Label label9;
        private TextBox soLuong_txt;
        private Label label8;
        private TextBox maSanPham_txt;
        private Label label3;
        private Button insertSanPham_btn;
    }
}
