﻿//namespace Boutique.GUI.Admin
//{
//    partial class Home
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            SuspendLayout();
//            // 
//            // Home
//            // 
//            AutoScaleDimensions = new SizeF(13F, 32F);
//            AutoScaleMode = AutoScaleMode.Font;
//            ClientSize = new Size(800, 450);
//            Name = "Home";
//            Text = "Home";
//            Load += Home_Load;
//            ResumeLayout(false);
//        }

//        #endregion


//    }
//}
namespace Boutique.GUI.Admin
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            btnMinisize = new Guna.UI2.WinForms.Guna2Button();
            panel1 = new Panel();
            btnCaidat = new Guna.UI2.WinForms.Guna2Button();
            btnQLNV = new Guna.UI2.WinForms.Guna2Button();
            btnBCDT = new Guna.UI2.WinForms.Guna2Button();
            btnQLSP = new Guna.UI2.WinForms.Guna2Button();
            panel2 = new Panel();
            pnlMoving = new Guna.UI2.WinForms.Guna2Panel();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(components);
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.CustomizableEdges = customizableEdges15;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.LightSkyBlue;
            btnExit.Font = new Font("Segoe UI", 9F);
            btnExit.ForeColor = Color.White;
            btnExit.ImageSize = new Size(40, 40);
            btnExit.Location = new Point(0, 0);
            btnExit.Margin = new Padding(3, 4, 3, 4);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnExit.Size = new Size(81, 84);
            btnExit.TabIndex = 0;
            btnExit.Click += btnExit_Click;
            // 
            // btnMinisize
            // 
            btnMinisize.CustomizableEdges = customizableEdges17;
            btnMinisize.DisabledState.BorderColor = Color.DarkGray;
            btnMinisize.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMinisize.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMinisize.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMinisize.FillColor = Color.LightSkyBlue;
            btnMinisize.Font = new Font("Segoe UI", 9F);
            btnMinisize.ForeColor = Color.White;
            btnMinisize.ImageSize = new Size(30, 30);
            btnMinisize.Location = new Point(0, 91);
            btnMinisize.Margin = new Padding(3, 4, 3, 4);
            btnMinisize.Name = "btnMinisize";
            btnMinisize.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnMinisize.Size = new Size(81, 84);
            btnMinisize.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(btnCaidat);
            panel1.Controls.Add(btnQLNV);
            panel1.Controls.Add(btnBCDT);
            panel1.Controls.Add(btnQLSP);
            panel1.Location = new Point(113, 15);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1912, 165);
            panel1.TabIndex = 2;
            // 
            // btnCaidat
            // 
            btnCaidat.BorderRadius = 18;
            btnCaidat.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCaidat.CustomizableEdges = customizableEdges19;
            btnCaidat.DisabledState.BorderColor = Color.DarkGray;
            btnCaidat.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCaidat.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCaidat.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCaidat.FillColor = Color.DodgerBlue;
            btnCaidat.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnCaidat.ForeColor = Color.White;
            btnCaidat.Location = new Point(1538, 4);
            btnCaidat.Margin = new Padding(3, 4, 3, 4);
            btnCaidat.Name = "btnCaidat";
            btnCaidat.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnCaidat.Size = new Size(308, 148);
            btnCaidat.TabIndex = 3;
            btnCaidat.Text = "Cài đặt";
            //btnCaidat.Click += btnCaidat_Click;
            // 
            // btnQLNV
            // 
            btnQLNV.BorderRadius = 18;
            btnQLNV.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnQLNV.CustomizableEdges = customizableEdges21;
            btnQLNV.DisabledState.BorderColor = Color.DarkGray;
            btnQLNV.DisabledState.CustomBorderColor = Color.DarkGray;
            btnQLNV.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnQLNV.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnQLNV.FillColor = Color.DodgerBlue;
            btnQLNV.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnQLNV.ForeColor = Color.White;
            btnQLNV.Location = new Point(1042, -3);
            btnQLNV.Margin = new Padding(3, 4, 3, 4);
            btnQLNV.Name = "btnQLNV";
            btnQLNV.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnQLNV.Size = new Size(308, 148);
            btnQLNV.TabIndex = 2;
            btnQLNV.Text = "Quản lí nhân viên";
            btnQLNV.Click += btnQLNV_Click;
            // 
            // btnBCDT
            // 
            btnBCDT.BorderRadius = 18;
            btnBCDT.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnBCDT.CustomizableEdges = customizableEdges23;
            btnBCDT.DisabledState.BorderColor = Color.DarkGray;
            btnBCDT.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBCDT.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBCDT.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBCDT.FillColor = Color.DodgerBlue;
            btnBCDT.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnBCDT.ForeColor = Color.White;
            btnBCDT.Location = new Point(520, 4);
            btnBCDT.Margin = new Padding(3, 4, 3, 4);
            btnBCDT.Name = "btnBCDT";
            btnBCDT.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnBCDT.Size = new Size(308, 148);
            btnBCDT.TabIndex = 1;
            btnBCDT.Text = "Báo cáo doanh thu";
            btnBCDT.Click += btnBCDT_Click;
            // 
            // btnQLSP
            // 
            btnQLSP.BorderRadius = 18;
            btnQLSP.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnQLSP.CustomizableEdges = customizableEdges25;
            btnQLSP.DisabledState.BorderColor = Color.DarkGray;
            btnQLSP.DisabledState.CustomBorderColor = Color.DarkGray;
            btnQLSP.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnQLSP.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnQLSP.FillColor = Color.DodgerBlue;
            btnQLSP.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnQLSP.ForeColor = Color.White;
            btnQLSP.Location = new Point(31, 4);
            btnQLSP.Margin = new Padding(3, 4, 3, 4);
            btnQLSP.Name = "btnQLSP";
            btnQLSP.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnQLSP.Size = new Size(308, 148);
            btnQLSP.TabIndex = 0;
            btnQLSP.Text = "Quản lí sản phẩm";
            btnQLSP.Click += btnQLSP_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Location = new Point(13, 218);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(2039, 1089);
            panel2.TabIndex = 3;
            //panel2.Paint += panel2_Paint;
            // 
            // pnlMoving
            // 
            pnlMoving.BackColor = Color.FromArgb(192, 255, 255);
            pnlMoving.CustomizableEdges = customizableEdges27;
            pnlMoving.Location = new Point(113, 201);
            pnlMoving.Margin = new Padding(3, 4, 3, 4);
            pnlMoving.Name = "pnlMoving";
            pnlMoving.ShadowDecoration.CustomizableEdges = customizableEdges28;
            pnlMoving.Size = new Size(325, 9);
            pnlMoving.TabIndex = 0;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            guna2Elipse3.TargetControl = this;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(2108, 1416);
            Controls.Add(pnlMoving);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(btnMinisize);
            Controls.Add(btnExit);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "admin";
            WindowState = FormWindowState.Maximized;
            Load += Home_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Guna.UI2.WinForms.Guna2Button btnMinisize;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button btnQLNV;
        private Guna.UI2.WinForms.Guna2Button btnBCDT;
        private Guna.UI2.WinForms.Guna2Button btnQLSP;
        private Guna.UI2.WinForms.Guna2Panel pnlMoving;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        //private All_User_Control.UC_Report uC_Report1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2Button btnCaidat;
    }
}